

const ProfilePage = () => {

  return (
    <>
      Profile Page
    </>
  )
}

export default ProfilePage;