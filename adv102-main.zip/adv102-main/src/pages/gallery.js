

const GalleryPage = () => {

  return (
    <>
      gallery Page
    </>
  )
}

export default GalleryPage;