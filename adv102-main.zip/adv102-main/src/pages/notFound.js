

const NotFoundPage = () => {

  return (
    <>
      page not found Page
    </>
  )
}

export default NotFoundPage;