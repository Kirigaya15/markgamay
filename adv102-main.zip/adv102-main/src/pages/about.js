

const AboutPage = () => {

  return (
    <div class="flex justify-between m-2 ">
      <p class="text-yellow-500">about Page</p>
      <p class='text-yellow-200'>2</p>
      <p class="text-red">3</p>
    </div>
  )
}

export default AboutPage;